# Blog - Content Management System
This Blog System is developed using HTML, CSS, JavaScript, PHP and MySQL.
To run this Blog System. Use the gdg.sql file and import it to your local PHPMyAdmin and then copy or clone the files to your local PHP Server directory.
It has all the features like:
1) Home Page
2) Add Post
3) Edit Post
4) Add Comment
5) Register
6) Login
7) Change Password
8) View Posts
9) Delete Post
10) Delete Comment
11) Featured Image
12) Admin Dashboard
13) Viewer Count for Each Post
