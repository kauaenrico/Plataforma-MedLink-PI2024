<?php
   define('HOST','localhost');
 define('USERNAME', 'root');
 define('PASSWORD','Inspiron@123');
 define('DB','gdg');
 $db = mysqli_connect(HOST,USERNAME,PASSWORD,DB);
?>