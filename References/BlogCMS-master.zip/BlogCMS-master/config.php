<?php
   define('HOST','SERVER_NAME');
 define('USERNAME', 'YOUR_USERNAME_HERE');
 define('PASSWORD','YOUR_PASSWORD_HERE');
 define('DB','DATABASE_NAME');
   $db = mysqli_connect(HOST,USERNAME,PASSWORD,DB);
?>
