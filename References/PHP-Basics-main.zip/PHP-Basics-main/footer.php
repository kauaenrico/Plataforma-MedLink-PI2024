<ul class="border border-t-black p-2">
    <li><a href='index.php?page=admindashboard' class="hover:text-blue-500">Admin Panel</a></li>
</ul>