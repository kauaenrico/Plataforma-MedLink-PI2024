<ul class="flex justify-center gap-1 list-none border border-b-black p-2 text-blue-500 font-bold ">
    <li><a href='index.php?page=home' class="px-4 py-2 hover:bg-blue-500 hover:text-white">Home</a></li>
    <li><a href='index.php?page=contact' class="px-4 py-2 hover:bg-blue-500 hover:text-white">Contact</a></li>
</ul>